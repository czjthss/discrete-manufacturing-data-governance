"""Research-group compression adapters."""
