# 面向离散制造垂域模型的自动化数据治理系统

这是课题三面向项目里程碑2的首个可运行版本。系统覆盖序列与关系数据的存储压缩、解析、对齐、高频采集、质量稳控、数据融合，以及工业数据规范化和综合测评框架。

## 启动

```bash
cd code
python3 run.py
```

浏览器访问 `http://127.0.0.1:8000`。

首版不依赖第三方 Python 包，建议使用 Python 3.11 或更高版本。服务启动后可在网页中：

- 一键运行 3.1–3.9 全部自测并生成 `data/reports/latest-self-test.json`；
- 分别运行每项指标；
- 导入或粘贴 CSV、TSV、JSON、JSONL、XML、INI 数据；
- 查看七维质量画像与规范化预览；
- 运行序列数据与工单关系的融合演示。
- 在“技术集成”视图查看每项指标的当前方法、待接入论文/代码、许可证和 commit 状态。

后端还提供：

- `GET /api/indicators`：指标、当前方法和计划接入项；
- `GET /api/integrations`：算法注册表、运行状态及 3.1–3.9 映射；
- `GET /api/references`：论文、仓库、许可证与 commit 元数据。

## 逐指标测试

在本目录可单独测试 3.1–3.9，也可一次运行全部指标并生成包含环境、源码版本和基准结果的 JSON 报告：

```bash
python3 run_indicator_tests.py 3.1
python3 run_indicator_tests.py all
```

各指标的算法文件、标注数据、测试文件、通过判据和逐项命令见 `algorithm_manifest.json`。完整测试大纲与运行说明见 `docs/课题三指标3.1-3.9算法测试大纲与运行说明.md` 或同名 Word 文档。

确定性生成含逐文件 SHA-256 清单的交付压缩包：

```bash
python3 tools/build_delivery_package.py
```

## 产物保留

系统以原子替换写入报告和序列文件，并通过目录级文件锁协调多进程清理。默认分别保留 256 份自测报告、256 份治理报告、128 个 3.1 自测运行目录和 256 份分析序列。报告与分析序列在写入后至少保留 600 秒；3.1 运行目录只有生成原子 `.completed` 标记并超过该保护期后才会成为清理候选。因此数量上限允许在保护期内暂时超出，写入方返回的路径不会立即被其他进程删除。

可通过以下环境变量调整各类别数量，值必须为正整数：

- `DGOV_RETENTION_RUN_REPORTS`
- `DGOV_RETENTION_GOVERNANCE_REPORTS`
- `DGOV_RETENTION_STORAGE_RUNS`
- `DGOV_RETENTION_ANALYSIS_SEQUENCES`
- `DGOV_RETENTION_GRACE_SECONDS`（默认 `600`，可设为非负秒数）

## 指标映射

| 指标 | 文件 | 里程碑2实现 |
|---|---|---|
| 3.1 | `governance/indicator_3_1.py` | 序列与关系数据存储、压缩、回读 |
| 3.2 | `governance/indicator_3_2.py` | 有界误差 PLA 时序压缩，目标 9:1 |
| 3.3 | `governance/indicator_3_3.py` | 格式识别与结构解析，目标 ≥95% |
| 3.4 | `governance/indicator_3_4.py` | 字段语义统一与时间窗对齐，目标 ≥90% |
| 3.5 | `governance/indicator_3_5.py` | 批量环形缓冲采集，目标 1.1kHz |
| 3.6 | `governance/indicator_3_6.py` | 完整性、一致性、时效性、有效性 ≥95% |
| 3.7 | `governance/indicator_3_7.py` | 序列数据与关系数据按需融合 |
| 3.8 | `governance/indicator_3_8.py` | 可扩展异构格式规范化测试框架 |
| 3.9 | `governance/indicator_3_9.py` | 七维工业数据质量综合测评 |

## 验收说明

本系统输出工程自测证据，并记录运行环境、测量过程和结果，用于项目复验与验收材料整理。

压缩模块采用有界误差方法，报告会同时披露压缩比、误差界和最大重构误差。正式测试时需由评审通过的测试方案明确原始字节口径、数据集、误差容限、硬件环境和重复次数。
